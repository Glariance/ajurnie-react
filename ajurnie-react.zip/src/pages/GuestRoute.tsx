// import { Navigate } from "react-router-dom";

// export default function GuestRoute({ children }: { children: JSX.Element }) {
//   const token = localStorage.getItem("auth_token");

//   if (token) {
//     return <Navigate to="/dashboard" replace />;
//   }

//   return children;
// }
